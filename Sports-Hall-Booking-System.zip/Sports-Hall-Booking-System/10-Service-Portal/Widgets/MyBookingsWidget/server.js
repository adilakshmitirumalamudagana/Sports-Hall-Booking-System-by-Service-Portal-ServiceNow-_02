(function() {
    var bookingUtils = new BookingUtils();

    if (input && input.action === 'cancel' && input.sys_id) {
        var gr = new GlideRecord('x_sports_hall_booking');
        if (gr.get(input.sys_id) && gr.getValue('requested_by') == gs.getUserID()) {
            gr.status = 'cancelled';
            gr.cancellation_reason = 'Cancelled by requester via portal';
            var ok = gr.update();
            data.success = !!ok;
        } else {
            data.success = false;
            data.message = 'Booking not found or not yours to cancel.';
        }
        return;
    }

    data.bookings = bookingUtils.getBookingsForUser();
})();
