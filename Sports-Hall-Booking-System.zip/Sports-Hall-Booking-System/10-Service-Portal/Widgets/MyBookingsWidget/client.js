function($scope) {
    var c = this;

    c.cancelBooking = function(booking) {
        if (!confirm('Cancel booking ' + booking.number + '?')) return;
        c.server.get({ action: 'cancel', sys_id: booking.sys_id }).then(function(response) {
            if (response.data.success) {
                booking.status = 'cancelled';
            } else {
                alert(response.data.message || 'Unable to cancel booking.');
            }
        });
    };
}
