(function() {
    var facilityMgr = new FacilityManager();
    var availability = new AvailabilityChecker();

    data.facilities = facilityMgr.getActiveFacilities();

    if (input && input.action === 'get_slots' && input.facility && input.date) {
        data.slots = availability.getSlotsForDate(input.facility, input.date);
    }
})();
