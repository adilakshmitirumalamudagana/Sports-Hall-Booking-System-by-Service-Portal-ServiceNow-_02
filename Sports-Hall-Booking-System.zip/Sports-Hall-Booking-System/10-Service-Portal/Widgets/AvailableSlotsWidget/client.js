function($scope, spUtil) {
    var c = this;
    c.selectedFacility = null;
    c.selectedDate = null;
    c.selectedSlot = null;
    c.slots = [];
    c.loading = false;

    var today = new Date();
    c.today = today.toISOString().slice(0, 10);
    c.selectedDate = c.today;

    c.selectFacility = function(facility) {
        c.selectedFacility = facility.sys_id;
        c.onFacilityChange();
    };

    c.onFacilityChange = function() {
        c.selectedSlot = null;
        c.fetchSlots();
    };

    c.onDateChange = function() {
        c.selectedSlot = null;
        c.fetchSlots();
    };

    c.fetchSlots = function() {
        if (!c.selectedFacility || !c.selectedDate) return;
        c.loading = true;
        c.server.get({
            action: 'get_slots',
            facility: c.selectedFacility,
            date: c.selectedDate
        }).then(function(response) {
            c.slots = response.data.slots || [];
            c.loading = false;
        });
    };

    c.selectSlot = function(slot) {
        if (slot.status !== 'available') return;
        c.selectedSlot = slot.sys_id;
        // Broadcast to sibling BookingFormWidget on the Booking page
        $scope.$emit('sports.slot.selected', {
            facility: c.selectedFacility,
            slot: slot
        });
    };
}
