function($scope) {
    var c = this;
    c.form = { purpose: '', attendee_count: 1, notes: '' };
    c.selectedSlot = null;
    c.facilityId = null;
    c.facilityName = '';
    c.submitting = false;
    c.errorMessage = '';
    c.successMessage = '';

    // Listen for slot selection broadcast from AvailableSlotsWidget
    $scope.$on('sports.slot.selected', function(evt, payload) {
        c.selectedSlot = payload.slot;
        c.facilityId = payload.facility;
        c.errorMessage = '';
        c.successMessage = '';
        $scope.$applyAsync();
    });

    c.submitBooking = function() {
        c.submitting = true;
        c.errorMessage = '';
        c.server.get({
            action: 'create_booking',
            facility: c.facilityId,
            time_slot: c.selectedSlot.sys_id,
            booking_date: c.selectedSlot.slot_date,
            start_time: c.selectedSlot.start_time,
            end_time: c.selectedSlot.end_time,
            purpose: c.form.purpose,
            attendee_count: c.form.attendee_count,
            notes: c.form.notes
        }).then(function(response) {
            c.submitting = false;
            if (response.data.success) {
                c.successMessage = 'Booking ' + response.data.number + ' submitted for approval!';
                c.selectedSlot = null;
                c.form = { purpose: '', attendee_count: 1, notes: '' };
            } else {
                c.errorMessage = response.data.message || 'Unable to submit booking.';
            }
        });
    };
}
