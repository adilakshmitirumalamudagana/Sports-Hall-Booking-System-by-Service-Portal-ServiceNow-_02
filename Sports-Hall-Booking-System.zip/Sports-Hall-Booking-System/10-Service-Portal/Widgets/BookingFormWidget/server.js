(function() {
    if (input && input.action === 'create_booking') {
        var bookingUtils = new BookingUtils();
        var result = bookingUtils.createBooking({
            facility: input.facility,
            time_slot: input.time_slot,
            booking_date: input.booking_date,
            start_time: input.start_time,
            end_time: input.end_time,
            purpose: input.purpose,
            attendee_count: input.attendee_count,
            notes: input.notes
        });
        data.success = result.success;
        data.number = result.number;
        data.message = result.message;
    }
})();
