(function() {
    var facilityMgr = new FacilityManager();
    var notifier = new NotificationHelper();
    var managedIds = facilityMgr.getManagedFacilityIds(); // empty array => admin sees all if has sports_admin role

    function inScope(gr) {
        if (gs.hasRole('x_sports.sports_admin')) return true;
        return managedIds.indexOf(gr.getValue('facility')) !== -1;
    }

    if (input && (input.action === 'approve' || input.action === 'reject') && input.sys_id) {
        var gr = new GlideRecord('x_sports_hall_booking');
        if (!gr.get(input.sys_id) || !inScope(gr)) {
            data.success = false;
            data.message = 'Booking not found or not in your scope.';
            return;
        }

        gr.approver = gs.getUserID();
        if (input.action === 'approve') {
            gr.status = 'approved';
        } else {
            gr.status = 'rejected';
            gr.rejection_reason = input.reason || '';
        }
        var ok = gr.update();
        data.success = !!ok;

        if (ok) {
            if (input.action === 'approve') notifier.notifyApproved(gr);
            else notifier.notifyRejected(gr);
        }
        return;
    }

    // Default: list pending bookings in this manager's scope
    var list = new GlideRecord('x_sports_hall_booking');
    list.addQuery('status', 'pending');
    if (!gs.hasRole('x_sports.sports_admin')) {
        list.addQuery('facility', 'IN', managedIds.join(','));
    }
    list.orderBy('booking_date');
    list.query();

    data.pending = [];
    while (list.next()) {
        data.pending.push({
            sys_id: list.getUniqueValue(),
            facility: list.facility.getDisplayValue(),
            booking_date: list.getValue('booking_date'),
            start_time: list.getValue('start_time'),
            end_time: list.getValue('end_time'),
            requested_by: list.requested_by.getDisplayValue(),
            purpose: list.getValue('purpose')
        });
    }
})();
