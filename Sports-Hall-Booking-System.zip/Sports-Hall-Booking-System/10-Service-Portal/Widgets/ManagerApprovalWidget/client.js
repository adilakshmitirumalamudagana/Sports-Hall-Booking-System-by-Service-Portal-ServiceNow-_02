function($scope) {
    var c = this;
    c.activeReject = null;
    c.rejectReason = {};

    c.approve = function(booking) {
        c.server.get({ action: 'approve', sys_id: booking.sys_id }).then(function(response) {
            if (response.data.success) {
                c.data.pending = c.data.pending.filter(function(b) { return b.sys_id !== booking.sys_id; });
            } else {
                alert(response.data.message || 'Unable to approve.');
            }
        });
    };

    c.reject = function(booking) {
        var reason = c.rejectReason[booking.sys_id] || 'Not specified';
        c.server.get({ action: 'reject', sys_id: booking.sys_id, reason: reason }).then(function(response) {
            if (response.data.success) {
                c.data.pending = c.data.pending.filter(function(b) { return b.sys_id !== booking.sys_id; });
                c.activeReject = null;
            } else {
                alert(response.data.message || 'Unable to reject.');
            }
        });
    };
}
