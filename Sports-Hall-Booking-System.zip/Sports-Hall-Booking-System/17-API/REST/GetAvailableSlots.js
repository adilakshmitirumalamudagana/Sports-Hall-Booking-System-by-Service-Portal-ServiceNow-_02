/*
 * Scripted REST Resource: GET /api/x_sports/booking/slots
 * Query params: facility (sys_id), date (yyyy-MM-dd)
 * Auth: requires x_sports.sports_user role
 */
(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {
    var facilityId = request.queryParams.facility;
    var date = request.queryParams.date;

    if (!facilityId || !date) {
        response.setStatus(400);
        return { error: 'facility and date query params are required' };
    }

    var checker = new AvailabilityChecker();
    var slots = checker.getSlotsForDate(facilityId, date);

    return { slots: slots };

})(request, response);
