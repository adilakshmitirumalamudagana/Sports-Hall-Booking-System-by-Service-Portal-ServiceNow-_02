/*
 * Scripted REST Resource: POST /api/x_sports/booking
 * Body: {facility, time_slot, booking_date, start_time, end_time, purpose, attendee_count, notes}
 * Auth: requires x_sports.sports_user role
 */
(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {
    var body = request.body.data || {};

    var required = ['facility', 'time_slot', 'booking_date', 'start_time', 'end_time'];
    for (var i = 0; i < required.length; i++) {
        if (!body[required[i]]) {
            response.setStatus(400);
            return { error: 'Missing required field: ' + required[i] };
        }
    }

    var bookingUtils = new BookingUtils();
    var result = bookingUtils.createBooking(body);

    if (!result.success) {
        response.setStatus(409);
        return { error: result.message };
    }

    response.setStatus(201);
    return { sys_id: result.sys_id, number: result.number };

})(request, response);
