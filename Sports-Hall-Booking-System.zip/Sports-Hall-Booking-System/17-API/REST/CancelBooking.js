/*
 * Scripted REST Resource: POST /api/x_sports/booking/{sys_id}/cancel
 * Body: {reason} (optional)
 * Auth: requires x_sports.sports_user role; caller must own the booking
 *       or hold x_sports.sports_manager / x_sports.sports_admin.
 */
(function process(/*RESTAPIRequest*/ request, /*RESTAPIResponse*/ response) {
    var sysId = request.pathParams.sys_id;
    var body = request.body.data || {};

    var gr = new GlideRecord('x_sports_hall_booking');
    if (!gr.get(sysId)) {
        response.setStatus(404);
        return { error: 'Booking not found' };
    }

    var isOwner = (gr.getValue('requested_by') == gs.getUserID());
    var isManager = gs.hasRole('x_sports.sports_manager') || gs.hasRole('x_sports.sports_admin');
    if (!isOwner && !isManager) {
        response.setStatus(403);
        return { error: 'Not authorized to cancel this booking' };
    }

    gr.status = 'cancelled';
    gr.cancellation_reason = body.reason || 'Cancelled via API';
    var ok = gr.update();

    if (!ok) {
        response.setStatus(500);
        return { error: 'Unable to cancel booking' };
    }

    return { sys_id: sysId, status: 'cancelled' };

})(request, response);
