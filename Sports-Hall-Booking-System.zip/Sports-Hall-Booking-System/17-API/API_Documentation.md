# Sports Hall Booking API

Base path: `/api/x_sports/booking` (Scripted REST API, scope `x_sports`)
Auth: ServiceNow session or OAuth token; caller must have role `x_sports.sports_user` at minimum.

## GET /slots
Get available time slots for a facility on a date.

**Query params**
| Param    | Type   | Required | Description        |
|----------|--------|----------|---------------------|
| facility | sys_id | yes      | Facility sys_id     |
| date     | string | yes      | `yyyy-MM-dd`        |

**Response 200**
```json
{ "slots": [ { "sys_id": "...", "start_time": "09:00:00", "end_time": "10:00:00", "status": "available" } ] }
```

## POST /
Create a new booking request.

**Body**
```json
{
  "facility": "sys_id",
  "time_slot": "sys_id",
  "booking_date": "2026-07-10",
  "start_time": "09:00:00",
  "end_time": "10:00:00",
  "purpose": "5-a-side practice",
  "attendee_count": 10,
  "notes": ""
}
```

**Response 201**
```json
{ "sys_id": "...", "number": "BKG0001001" }
```
**Response 409** — slot no longer available: `{ "error": "..." }`

## POST /{sys_id}/cancel
Cancel an existing booking (owner or manager/admin only).

**Body (optional)**
```json
{ "reason": "Plans changed" }
```

**Response 200**
```json
{ "sys_id": "...", "status": "cancelled" }
```
**Response 403** — not authorized. **Response 404** — booking not found.
