/*
 * Script Include: AvailabilityChecker
 * Client callable: false
 * Purpose: Computes real-time slot availability for a facility/date,
 * used by AvailableSlotsWidget and GetAvailableSlots REST resource.
 */
var AvailabilityChecker = Class.create();
AvailabilityChecker.prototype = {
    initialize: function() {},

    /**
     * @param {String} facilityId
     * @param {String} dateStr yyyy-MM-dd
     * @returns {Array} list of {sys_id, start_time, end_time, status}
     */
    getSlotsForDate: function(facilityId, dateStr) {
        var slots = [];
        var gr = new GlideRecord('x_sports_time_slot');
        gr.addQuery('facility', facilityId);
        gr.addQuery('slot_date', dateStr);
        gr.orderBy('start_time');
        gr.query();
        while (gr.next()) {
            slots.push({
                sys_id: gr.getUniqueValue(),
                start_time: gr.getValue('start_time'),
                end_time: gr.getValue('end_time'),
                status: gr.getValue('status')
            });
        }
        return slots;
    },

    /**
     * True if the facility has zero available slots left for a date
     * (used to grey out dates in the portal calendar).
     */
    isFullyBooked: function(facilityId, dateStr) {
        var gr = new GlideRecord('x_sports_time_slot');
        gr.addQuery('facility', facilityId);
        gr.addQuery('slot_date', dateStr);
        gr.addQuery('status', 'available');
        gr.query();
        return !gr.hasNext();
    },

    type: 'AvailabilityChecker'
};
