/*
 * Script Include: FacilityManager
 * Client callable: false
 * Purpose: Facility CRUD helpers + the "is this user the manager of this
 * facility" check used to scope ManagerApprovalWidget and the write ACL.
 */
var FacilityManager = Class.create();
FacilityManager.prototype = {
    initialize: function() {},

    getActiveFacilities: function(facilityType) {
        var gr = new GlideRecord('x_sports_facility');
        gr.addQuery('active', true);
        if (facilityType) gr.addQuery('facility_type', facilityType);
        gr.orderBy('name');
        gr.query();
        var out = [];
        while (gr.next()) {
            out.push({
                sys_id: gr.getUniqueValue(),
                name: gr.getValue('name'),
                type: gr.getValue('facility_type'),
                location: gr.getValue('location'),
                capacity: gr.getValue('capacity'),
                image: gr.getValue('image'),
                maintenance_mode: gr.getValue('maintenance_mode') == '1'
            });
        }
        return out;
    },

    isManagerOf: function(facilityId, userId) {
        userId = userId || gs.getUserID();
        var gr = new GlideRecord('x_sports_facility');
        if (!gr.get(facilityId)) return false;
        return gr.getValue('manager') == userId;
    },

    /** Facilities managed by the given user, for ManagerApprovalWidget scoping */
    getManagedFacilityIds: function(userId) {
        userId = userId || gs.getUserID();
        var gr = new GlideRecord('x_sports_facility');
        gr.addQuery('manager', userId);
        gr.query();
        var ids = [];
        while (gr.next()) ids.push(gr.getUniqueValue());
        return ids;
    },

    type: 'FacilityManager'
};
