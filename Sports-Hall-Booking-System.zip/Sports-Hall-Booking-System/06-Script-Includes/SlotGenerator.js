/*
 * Script Include: SlotGenerator
 * Client callable: false
 * Purpose: Generates x_sports_time_slot rows for a facility/date range
 * based on the facility's open/close time and slot_duration_minutes.
 * Invoked by 08-Scheduled-Jobs/Daily_Slot_Generation.js
 */
var SlotGenerator = Class.create();
SlotGenerator.prototype = {
    initialize: function() {},

    /**
     * Generates slots for one facility for a single date if they don't
     * already exist (idempotent - safe to run daily).
     */
    generateForFacilityAndDate: function(facilityId, dateStr) {
        var facilityGR = new GlideRecord('x_sports_facility');
        if (!facilityGR.get(facilityId) || facilityGR.active != true) return 0;

        var existing = new GlideRecord('x_sports_time_slot');
        existing.addQuery('facility', facilityId);
        existing.addQuery('slot_date', dateStr);
        existing.query();
        if (existing.hasNext()) return 0; // already generated

        var durationMin = parseInt(facilityGR.slot_duration_minutes, 10) || 60;
        var open = facilityGR.getValue('open_time');   // 'HH:mm:ss'
        var close = facilityGR.getValue('close_time');

        var cursorSec = this._timeToSeconds(open);
        var closeSec = this._timeToSeconds(close);
        var created = 0;

        while (cursorSec + (durationMin * 60) <= closeSec) {
            var startSec = cursorSec;
            var endSec = cursorSec + (durationMin * 60);

            var slot = new GlideRecord('x_sports_time_slot');
            slot.initialize();
            slot.facility = facilityId;
            slot.slot_date = dateStr;
            slot.start_time = this._secondsToTime(startSec);
            slot.end_time = this._secondsToTime(endSec);
            slot.status = 'available';
            slot.insert();

            cursorSec = endSec;
            created++;
        }
        return created;
    },

    generateForAllActiveFacilities: function(dateStr) {
        var gr = new GlideRecord('x_sports_facility');
        gr.addQuery('active', true);
        gr.query();
        var total = 0;
        while (gr.next()) {
            total += this.generateForFacilityAndDate(gr.getUniqueValue(), dateStr);
        }
        return total;
    },

    _timeToSeconds: function(hhmmss) {
        var parts = hhmmss.split(':');
        return (parseInt(parts[0], 10) * 3600) + (parseInt(parts[1], 10) * 60) + parseInt(parts[2] || 0, 10);
    },

    _secondsToTime: function(totalSec) {
        var h = Math.floor(totalSec / 3600);
        var m = Math.floor((totalSec % 3600) / 60);
        var s = totalSec % 60;
        function pad(n) { return (n < 10 ? '0' : '') + n; }
        return pad(h) + ':' + pad(m) + ':' + pad(s);
    },

    type: 'SlotGenerator'
};
