/*
 * Script Include: BookingUtils
 * Client callable: false
 * Purpose: Shared helper functions for creating/reading bookings, used
 * by widget server scripts, REST resources, and scheduled jobs.
 */
var BookingUtils = Class.create();
BookingUtils.prototype = {
    initialize: function() {},

    /**
     * Creates a booking + puts a matching time_slot on hold in one call.
     * @param {Object} data {facility, time_slot, booking_date, start_time, end_time, purpose, attendee_count, notes}
     * @returns {Object} {success, sys_id, number, message}
     */
    createBooking: function(data) {
        var slot = new GlideRecord('x_sports_time_slot');
        if (!slot.get(data.time_slot) || slot.status != 'available') {
            return { success: false, message: 'Selected slot is not available.' };
        }

        var gr = new GlideRecord('x_sports_hall_booking');
        gr.initialize();
        gr.facility = data.facility;
        gr.time_slot = data.time_slot;
        gr.booking_date = data.booking_date;
        gr.start_time = data.start_time;
        gr.end_time = data.end_time;
        gr.purpose = data.purpose || '';
        gr.attendee_count = data.attendee_count || 1;
        gr.notes = data.notes || '';
        gr.requested_by = gs.getUserID();
        gr.status = 'pending';

        var sysId = gr.insert();
        if (!sysId) {
            return { success: false, message: 'Unable to create booking. ' + gr.getLastErrorMessage() };
        }
        return { success: true, sys_id: sysId, number: gr.getValue('number') };
    },

    /**
     * Returns bookings for a given user (default: current user).
     */
    getBookingsForUser: function(userId) {
        userId = userId || gs.getUserID();
        var gr = new GlideRecord('x_sports_hall_booking');
        gr.addQuery('requested_by', userId);
        gr.orderByDesc('booking_date');
        gr.query();
        var results = [];
        while (gr.next()) {
            results.push(this._toPayload(gr));
        }
        return results;
    },

    _toPayload: function(gr) {
        return {
            sys_id: gr.getUniqueValue(),
            number: gr.getValue('number'),
            facility: gr.facility.getDisplayValue(),
            facility_id: gr.getValue('facility'),
            booking_date: gr.getValue('booking_date'),
            start_time: gr.getValue('start_time'),
            end_time: gr.getValue('end_time'),
            status: gr.getValue('status'),
            purpose: gr.getValue('purpose')
        };
    },

    type: 'BookingUtils'
};
