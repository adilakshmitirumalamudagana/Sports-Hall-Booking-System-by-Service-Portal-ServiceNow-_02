/*
 * Script Include: NotificationHelper
 * Client callable: false
 * Purpose: Central place to trigger the 09-Notifications email events
 * from business rules / flows, keeping event names consistent.
 */
var NotificationHelper = Class.create();
NotificationHelper.prototype = {
    initialize: function() {},

    EVENTS: {
        SUBMITTED: 'x_sports.booking.submitted',
        APPROVED: 'x_sports.booking.approved',
        REJECTED: 'x_sports.booking.rejected',
        CANCELLED: 'x_sports.booking.cancelled',
        REMINDER: 'x_sports.booking.reminder'
    },

    fireBookingEvent: function(eventName, bookingGR, extraParm) {
        gs.eventQueue(eventName, bookingGR, bookingGR.getValue('requested_by'), extraParm || '');
    },

    notifySubmitted: function(bookingGR) {
        this.fireBookingEvent(this.EVENTS.SUBMITTED, bookingGR);
    },
    notifyApproved: function(bookingGR) {
        this.fireBookingEvent(this.EVENTS.APPROVED, bookingGR);
    },
    notifyRejected: function(bookingGR) {
        this.fireBookingEvent(this.EVENTS.REJECTED, bookingGR, bookingGR.getValue('rejection_reason'));
    },
    notifyCancelled: function(bookingGR) {
        this.fireBookingEvent(this.EVENTS.CANCELLED, bookingGR, bookingGR.getValue('cancellation_reason'));
    },
    notifyReminder: function(bookingGR) {
        this.fireBookingEvent(this.EVENTS.REMINDER, bookingGR);
    },

    type: 'NotificationHelper'
};
