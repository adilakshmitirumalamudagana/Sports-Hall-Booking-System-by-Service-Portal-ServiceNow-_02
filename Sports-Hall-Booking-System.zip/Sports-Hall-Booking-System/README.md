# Sports Hall Booking System (ServiceNow Scoped App)

A self-service portal for booking sports facilities, with multi-stage
manager approval, automated notifications, and admin configuration.

## What's built so far

| Folder | Contents | Status |
|---|---|---|
| `03-Database` | 5 tables, dictionary overrides, 2 relationships | ✅ Complete |
| `04-Security` | 3 roles, 4 ACLs, portal user criteria | ✅ Complete |
| `05-Business-Rules` | 5 rules: validation, dedup, status sync, cancellation, audit | ✅ Complete |
| `06-Script-Includes` | 5 reusable server APIs | ✅ Complete |
| `07-Flow-Designer` | 5 flow blueprints (JSON specs to rebuild in Flow Designer UI) | ✅ Blueprint |
| `08-Scheduled-Jobs` | 4 jobs: cleanup, reminders, slot generation, utilization | ✅ Complete |
| `09-Notifications` | 5 email templates | ✅ Complete |
| `10-Service-Portal` | Portal, theme, 6 pages, 4 full widgets, menus | ✅ Complete |
| `11-Client-Scripts` | 4 backoffice-form client scripts | ✅ Complete |
| `12-UI-Policies` | 3 UI policies | ✅ Complete |
| `17-API` | 3 Scripted REST resources + docs | ✅ Complete |
| `01-Project-Documents`, `02-Application-Configuration`, `13-Reports`, `14-Dashboards`, `15-Data-Migration`, `16-Testing`, `18-Sample-Data` | — | ⬜ Not yet built |

## How to import into ServiceNow

This kit is delivered as **readable source files**, not a binary Update
Set XML export (those are enormous and opaque to review). To bring it
into an instance:

1. **Scoped app**: Create application `x_sports` in Studio.
2. **Tables**: In Studio, create each table from `03-Database/Tables/*.xml`
   using the field lists given (type, label, mandatory, choices, defaults).
3. **Security**: Create the 3 roles, then the 4 ACLs (`04-Security`),
   pasting the `<script>` blocks into the ACL script field.
4. **Script Includes**: Create each one in `06-Script-Includes` as a
   Script Include record (paste the `.js` content directly — they're
   already in ServiceNow's `Class.create()` pattern).
5. **Business Rules**: Create each `.js` in `05-Business-Rules` as a
   Business Rule on `x_sports_hall_booking`, matching the when/order/filter
   noted in each file's header comment.
6. **Flows**: Use `07-Flow-Designer/*.json` as a build blueprint — open
   Flow Designer and recreate each trigger/action per the spec (Flow
   Designer flows can't be hand-authored as text; the JSON here is the
   design document, not an importable artifact).
7. **Scheduled Jobs**: Create each as a Scheduled Script Execution with
   the cadence noted in its header comment.
8. **Notifications**: Create Email Notifications on `x_sports_hall_booking`
   triggered by the named event; paste subject/body.
9. **Service Portal**: Create the portal + theme, then each page, then
   each widget (HTML/CSS/Client/Server scripts go in the matching widget
   fields). Wire the header/footer menus.
10. **Client Scripts / UI Policies**: Create on `x_sports_hall_booking`
    exactly as named.
11. **REST API**: Create Scripted REST API `x_sports/booking` with the
    3 resources in `17-API/REST`.

## Recommended build order (next steps)
1. Tables → Security → Business Rules → Script Includes (foundation)
2. Flows + Notifications + Scheduled Jobs (automation)
3. Service Portal (user-facing)
4. `13-Reports`, `14-Dashboards` (visibility)
5. `16-Testing` (ATF scripts), `15-Data-Migration`, `18-Sample-Data`
6. `01-Project-Documents` (BRD/FRD/etc. — can be generated as Word docs
   once functionality is finalized, so they describe the *actual* build)

## Not yet built — tell me which to do next
- Reports & Dashboards (13, 14)
- Sample data + test scripts (16, 18)
- ATF automated tests
- Data migration scripts (15)
- Formal project documents (01) — BRD, FRD, Technical Design, User/Admin Guides
