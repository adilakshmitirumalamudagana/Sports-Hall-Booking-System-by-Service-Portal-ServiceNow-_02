/*
 * Scheduled Job: Utilization Report Generator
 * Run: Weekly (Monday 06:00)
 * Purpose: Pre-aggregates last week's facility utilization % into a
 * lightweight summary log, feeding 14-Dashboards/Sports_Manager_Dashboard.xml
 * without expensive live aggregation on every dashboard load.
 */
(function() {
    var facilities = new GlideRecord('x_sports_facility');
    facilities.addQuery('active', true);
    facilities.query();

    while (facilities.next()) {
        var totalSlots = new GlideAggregate('x_sports_time_slot');
        totalSlots.addQuery('facility', facilities.getUniqueValue());
        totalSlots.addQuery('slot_date', '>=', gs.daysAgoStart(7));
        totalSlots.addQuery('slot_date', '<=', gs.daysAgoEnd(0));
        totalSlots.addAggregate('COUNT');
        totalSlots.query();
        var total = totalSlots.next() ? totalSlots.getAggregate('COUNT') : 0;

        var bookedSlots = new GlideAggregate('x_sports_time_slot');
        bookedSlots.addQuery('facility', facilities.getUniqueValue());
        bookedSlots.addQuery('slot_date', '>=', gs.daysAgoStart(7));
        bookedSlots.addQuery('slot_date', '<=', gs.daysAgoEnd(0));
        bookedSlots.addQuery('status', 'booked');
        bookedSlots.addAggregate('COUNT');
        bookedSlots.query();
        var booked = bookedSlots.next() ? bookedSlots.getAggregate('COUNT') : 0;

        var pct = total > 0 ? Math.round((booked / total) * 100) : 0;
        gs.info('Utilization [' + facilities.getValue('name') + ']: ' + booked + '/' + total + ' = ' + pct + '%');
        // Optionally: write to a custom x_sports_utilization_snapshot table for charting.
    }
})();
