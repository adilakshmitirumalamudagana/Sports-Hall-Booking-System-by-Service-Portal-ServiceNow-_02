/*
 * Scheduled Job: Reminder Notification
 * Run: Hourly
 * Purpose: Sends a reminder email ~24h before an approved booking's
 * start time. Add a boolean 'reminder_sent' field to
 * x_sports_hall_booking before enabling this job.
 */
(function() {
    var helper = new NotificationHelper();

    var windowStart = new GlideDateTime();
    var windowEnd = new GlideDateTime();
    windowEnd.addSeconds(24 * 3600);

    var gr = new GlideRecord('x_sports_hall_booking');
    gr.addQuery('status', 'approved');
    gr.addQuery('reminder_sent', false);
    gr.query();

    while (gr.next()) {
        var start = new GlideDateTime(gr.getValue('booking_date') + ' ' + gr.getValue('start_time'));
        if (start.compareTo(windowStart) >= 0 && start.compareTo(windowEnd) <= 0) {
            helper.notifyReminder(gr);
            gr.reminder_sent = true;
            gr.update();
        }
    }
})();
