/*
 * Scheduled Job: Daily Slot Generation
 * Run: Daily, 00:05
 * Purpose: Rolls the booking horizon forward one day by generating
 * x_sports_time_slot rows for (today + max advance_booking_days) across
 * all active facilities. Idempotent - see SlotGenerator.
 */
(function() {
    var generator = new SlotGenerator();

    var facilities = new GlideRecord('x_sports_facility');
    facilities.addQuery('active', true);
    facilities.query();

    var totalCreated = 0;
    while (facilities.next()) {
        var horizonDays = parseInt(facilities.getValue('advance_booking_days'), 10) || 14;
        var targetDate = new GlideDate();
        targetDate.addDaysUTC(horizonDays);
        totalCreated += generator.generateForFacilityAndDate(facilities.getUniqueValue(), targetDate.getValue());
    }

    gs.info('Daily_Slot_Generation created ' + totalCreated + ' new slots');
})();
