/*
 * Scheduled Job: Expired Booking Cleanup
 * Run: Daily, 00:15
 * Purpose: Auto-cancels bookings still 'pending' after 3 days with no
 * manager action, and marks past 'approved' bookings as 'completed'.
 */
(function() {
    var PENDING_TIMEOUT_DAYS = 3;

    // 1. Auto-cancel stale pending requests
    var stale = new GlideRecord('x_sports_hall_booking');
    stale.addQuery('status', 'pending');
    stale.addQuery('sys_created_on', '<', gs.daysAgo(PENDING_TIMEOUT_DAYS));
    stale.query();
    while (stale.next()) {
        stale.status = 'cancelled';
        stale.cancellation_reason = 'Auto-cancelled: no approval action within ' + PENDING_TIMEOUT_DAYS + ' days';
        stale.update();
    }

    // 2. Mark past approved bookings as completed
    var past = new GlideRecord('x_sports_hall_booking');
    past.addQuery('status', 'approved');
    past.addQuery('booking_date', '<', new GlideDate().getValue());
    past.query();
    while (past.next()) {
        past.status = 'completed';
        past.update();
    }

    gs.info('Expired_Booking_Cleanup complete');
})();
