/*
 * Business Rule: Prevent Duplicate Booking
 * Table: x_sports_hall_booking
 * When: before, insert
 * Order: 110 (runs after Validate_Slot_Availability)
 *
 * Purpose: Belt-and-braces check against race conditions - blocks a
 * second booking from being created against the same facility/date/time
 * range that already has a pending or approved booking, even if two
 * requests slip through the UI for the same slot at once.
 */
(function executeRule(current, previous) {

    var dup = new GlideRecord('x_sports_hall_booking');
    dup.addQuery('facility', current.facility);
    dup.addQuery('booking_date', current.booking_date);
    dup.addQuery('status', 'IN', 'pending,approved');
    // overlap test: existing.start < new.end AND existing.end > new.start
    dup.addQuery('start_time', '<', current.end_time);
    dup.addQuery('end_time', '>', current.start_time);
    dup.query();

    if (dup.hasNext()) {
        gs.addErrorMessage('Another booking already exists for this facility and time range.');
        current.setAbortAction(true);
    }

})(current, previous);
