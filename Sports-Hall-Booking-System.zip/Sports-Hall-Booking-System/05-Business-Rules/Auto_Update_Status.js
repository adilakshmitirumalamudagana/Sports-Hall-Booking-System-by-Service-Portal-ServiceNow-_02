/*
 * Business Rule: Auto Update Status
 * Table: x_sports_hall_booking
 * When: after, insert + update
 *
 * Purpose: Keeps the linked x_sports_time_slot record's status in sync
 * with the booking's status, and stamps approval_date automatically.
 * (The actual approval/rejection decision itself is made in
 * 07-Flow-Designer/Approval_Flow.json - this BR only mirrors the result
 * onto the slot record and handles timestamps.)
 */
(function executeRule(current, previous) {

    var slotGR = new GlideRecord('x_sports_time_slot');
    if (!slotGR.get(current.time_slot)) return;

    if (current.operation() == 'insert') {
        slotGR.status = 'held';
        slotGR.booking = current.sys_id;
        slotGR.update();
        return;
    }

    if (!current.status.changes()) return;

    switch (current.status.toString()) {
        case 'approved':
            slotGR.status = 'booked';
            slotGR.update();
            if (!current.approval_date) {
                current.approval_date = new GlideDateTime();
                current.update();
            }
            break;
        case 'rejected':
        case 'cancelled':
            slotGR.status = 'available';
            slotGR.booking = '';
            slotGR.update();
            break;
        case 'pending':
            slotGR.status = 'held';
            slotGR.update();
            break;
        default:
            break;
    }

})(current, previous);
