/*
 * Business Rule: Audit History
 * Table: x_sports_hall_booking
 * When: after, insert + update
 * Order: 1000 (runs last)
 *
 * Purpose: Writes an immutable row to x_sports_booking_history every
 * time the booking is created or its status changes, for reporting
 * and dispute resolution (13-Reports/Cancellation_Report.xml relies
 * on this table).
 */
(function executeRule(current, previous) {

    var shouldLog = (current.operation() == 'insert') || current.status.changes();
    if (!shouldLog) return;

    var h = new GlideRecord('x_sports_booking_history');
    h.initialize();
    h.booking = current.sys_id;
    h.from_status = (current.operation() == 'insert') ? '' : previous.status.toString();
    h.to_status = current.status.toString();
    h.changed_by = gs.getUserID();
    h.changed_on = new GlideDateTime();
    h.comment = (current.status == 'rejected') ? current.rejection_reason.toString()
              : (current.status == 'cancelled') ? current.cancellation_reason.toString()
              : '';
    h.insert();

})(current, previous);
