/*
 * Business Rule: Validate Slot Availability
 * Table: x_sports_hall_booking
 * When: before, insert + update
 * Filter: current.status.changesTo('pending') OR insert
 * Order: 100 (runs before Prevent_Duplicate_Booking)
 *
 * Purpose: Confirms the referenced time_slot is still 'available' (or
 * 'held' by this same requester) and within the facility's advance
 * booking window and operating hours before allowing the record through.
 */
(function executeRule(current, previous /*null when async*/) {

    var slotGR = new GlideRecord('x_sports_time_slot');
    if (!slotGR.get(current.time_slot)) {
        gs.addErrorMessage('Selected time slot no longer exists.');
        current.setAbortAction(true);
        return;
    }

    // Slot must be available, or already held by this requester (e.g. re-submit)
    var isHeldByMe = (slotGR.status == 'held' && slotGR.booking == current.sys_id);
    if (slotGR.status != 'available' && !isHeldByMe) {
        gs.addErrorMessage('This time slot is no longer available. Please choose another slot.');
        current.setAbortAction(true);
        return;
    }

    // Enforce facility advance-booking window
    var facilityGR = new GlideRecord('x_sports_facility');
    if (facilityGR.get(current.facility)) {
        if (facilityGR.maintenance_mode == true) {
            gs.addErrorMessage('This facility is currently under maintenance and cannot be booked.');
            current.setAbortAction(true);
            return;
        }

        var maxDays = parseInt(facilityGR.advance_booking_days, 10) || 14;
        var today = new GlideDate();
        var requestDate = new GlideDate();
        requestDate.setValue(current.booking_date);

        var gdt = new GlideDateTime();
        var daysOut = gs.dateDiff(today.getValue(), requestDate.getValue(), true) / 86400;
        if (daysOut > maxDays) {
            gs.addErrorMessage('Bookings for this facility can only be made up to ' + maxDays + ' days in advance.');
            current.setAbortAction(true);
            return;
        }
        if (daysOut < 0) {
            gs.addErrorMessage('You cannot book a date in the past.');
            current.setAbortAction(true);
            return;
        }
    }

    // Check for maintenance windows overlapping the requested slot
    var maintGR = new GlideRecord('x_sports_maintenance');
    maintGR.addQuery('facility', current.facility);
    maintGR.addQuery('start_date', '<=', current.booking_date + ' ' + current.end_time);
    maintGR.addQuery('end_date', '>=', current.booking_date + ' ' + current.start_time);
    maintGR.query();
    if (maintGR.hasNext()) {
        gs.addErrorMessage('This facility has a scheduled maintenance window that conflicts with the selected time.');
        current.setAbortAction(true);
    }

})(current, previous);
