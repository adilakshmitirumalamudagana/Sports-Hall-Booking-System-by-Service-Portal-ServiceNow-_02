/*
 * Business Rule: Booking Cancellation
 * Table: x_sports_hall_booking
 * When: before, update
 * Filter: current.status.changesTo('cancelled')
 *
 * Purpose: Enforces cancellation rules - only the requester or a
 * facility manager/admin may cancel, and only while the booking is
 * still upcoming (not already completed).
 */
(function executeRule(current, previous) {

    var isOwner   = (current.requested_by == gs.getUserID());
    var isManager = gs.hasRole('x_sports.sports_manager') || gs.hasRole('x_sports.sports_admin');

    if (!isOwner && !isManager) {
        gs.addErrorMessage('You are not authorized to cancel this booking.');
        current.setAbortAction(true);
        return;
    }

    if (previous.status == 'completed') {
        gs.addErrorMessage('Completed bookings cannot be cancelled.');
        current.setAbortAction(true);
        return;
    }

    current.cancelled_by = gs.getUserID();
    if (!current.cancellation_reason) {
        current.cancellation_reason = 'Cancelled via Service Portal';
    }

})(current, previous);
