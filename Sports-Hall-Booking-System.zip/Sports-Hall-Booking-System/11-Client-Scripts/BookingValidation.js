/*
 * Client Script: Booking Validation
 * Table: x_sports_hall_booking
 * Type: onSubmit
 * Applies to: platform form (backoffice); portal form validation is
 * handled inline in BookingFormWidget/client.js
 */
function onSubmit() {
    var attendees = g_form.getValue('attendee_count');
    if (attendees && parseInt(attendees, 10) < 1) {
        g_form.showFieldMsg('attendee_count', 'Attendee count must be at least 1.', 'error');
        return false;
    }
    return true;
}
