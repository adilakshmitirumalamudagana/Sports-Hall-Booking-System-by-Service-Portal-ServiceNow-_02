/*
 * Client Script: Facility Validation
 * Table: x_sports_hall_booking
 * Type: onChange (field: facility)
 * Purpose: Warns the user immediately (backoffice form) if the chosen
 * facility is currently in maintenance mode, before they pick a slot.
 */
function onChange(control, oldValue, newValue, isLoading) {
    if (isLoading || !newValue) return;

    var ga = new GlideAjax('FacilityManager');
    ga.addParam('sysparm_name', 'isInMaintenanceAjax'); // add this method server-side if exposing via GlideAjax
    ga.addParam('sysparm_facility_id', newValue);
    ga.getXMLAnswer(function(answer) {
        if (answer === 'true') {
            g_form.showFieldMsg('facility', 'This facility is currently under maintenance.', 'warning');
        } else {
            g_form.hideFieldMsg('facility');
        }
    });
}
