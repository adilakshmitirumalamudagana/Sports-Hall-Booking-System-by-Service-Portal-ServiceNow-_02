/*
 * Client Script: Date Validation
 * Table: x_sports_hall_booking
 * Type: onChange (field: booking_date)
 */
function onChange(control, oldValue, newValue, isLoading) {
    if (isLoading || !newValue) return;

    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var selected = new Date(newValue);

    if (selected < today) {
        g_form.showFieldMsg('booking_date', 'Booking date cannot be in the past.', 'error');
        g_form.setValue('booking_date', '');
    } else {
        g_form.hideFieldMsg('booking_date');
    }
}
