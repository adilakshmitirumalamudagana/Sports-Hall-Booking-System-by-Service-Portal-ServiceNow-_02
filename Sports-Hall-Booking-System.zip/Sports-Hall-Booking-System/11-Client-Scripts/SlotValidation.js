/*
 * Client Script: Slot Validation
 * Table: x_sports_hall_booking
 * Type: onChange (field: time_slot)
 * Purpose: Auto-populates start_time/end_time/booking_date from the
 * chosen time_slot record via GlideAjax, keeping fields in sync when
 * a slot is picked from the platform reference field (backoffice use).
 */
function onChange(control, oldValue, newValue, isLoading) {
    if (isLoading || !newValue) return;

    var ga = new GlideAjax('AvailabilityChecker');
    ga.addParam('sysparm_name', 'getSlotDetailsAjax'); // add this method server-side if exposing via GlideAjax
    ga.addParam('sysparm_slot_id', newValue);
    ga.getXMLAnswer(function(answer) {
        if (!answer) return;
        var slot = JSON.parse(answer);
        g_form.setValue('booking_date', slot.slot_date);
        g_form.setValue('start_time', slot.start_time);
        g_form.setValue('end_time', slot.end_time);
    });
}
